import { GoogleGenAI, Type } from '@google/genai';
import { AiSuggestion, HealthMetricState, TodoItem } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });

export async function fetchPersonalizedHealthSuggestions(
  metrics: HealthMetricState,
  activeTodos: TodoItem[]
): Promise<AiSuggestion[]> {
  const prompt = `
Generate 4 highly tailored, practical daily health tips for a user with the following profile:
- Current Mood: ${metrics.mood}
- Sleep Last Night: ${metrics.sleepHours} hours
- Water intake so far: ${metrics.waterGlasses}/8 glasses
- Remaining daily tasks count: ${activeTodos.filter(t => !t.completed).length}

Make recommendations specific, compassionate, scientifically sound, and easy to complete in under 15 minutes today.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an evidence-based clinical wellness consultant and supportive lifestyle coach.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              category: {
                type: Type.STRING,
                description: 'One of: nutrition, exercise, recovery, mental-clarity',
              },
              headline: { type: Type.STRING, description: 'Catchy 3-6 word recommendation' },
              actionableTip: { type: Type.STRING, description: 'Direct advice what to do right now' },
              scientificWhy: { type: Type.STRING, description: 'Brief 1-sentence physiological reason' },
              quickActionTodoTitle: {
                type: Type.STRING,
                description: 'A crisp todo item title the user can add directly to their list',
              },
            },
            required: ['id', 'category', 'headline', 'actionableTip', 'scientificWhy', 'quickActionTodoTitle'],
          },
        },
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    return parsed.length > 0 ? parsed : getFallbackSuggestions();
  } catch (error) {
    console.error('Gemini Health Suggestions Error:', error);
    return getFallbackSuggestions();
  }
}

export async function askHealthCoach(
  userQuery: string,
  context: { metrics: HealthMetricState; pendingTodosCount: number }
): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `User Query: "${userQuery}".
User Context:
- Mood: ${context.metrics.mood}
- Sleep: ${context.metrics.sleepHours} hrs
- Water: ${context.metrics.waterGlasses}/8 glasses
- Unfinished tasks: ${context.pendingTodosCount}

Provide a supportive, concise, and structured reply (maximum 3 concise paragraphs or bullet points). If medical diagnosis is asked, include gentle safety guidance while providing safe lifestyle best practices.`,
      config: {
        systemInstruction: 'You are an empathetic, encouraging wellness mentor. You provide realistic, balanced daily routines and nutritional/mental health tips.',
      },
    });

    return response.text || "Listen to your body, take steady deep breaths, and tackle one small action at a time.";
  } catch (err) {
    console.error('Ask Coach Error:', err);
    return "I'm having a brief connection pause. In the meantime, drink a glass of water and take 5 slow deep breaths!";
  }
}

function getFallbackSuggestions(): AiSuggestion[] {
  return [
    {
      id: 'f1',
      category: 'hydration',
      headline: 'Electrolyte & Water Boost',
      actionableTip: 'Drink 2 full glasses of lukewarm water with a tiny pinch of sea salt or lemon juice.',
      scientificWhy: 'Optimizes cellular fluid balance and sharpens alertness after midday fatigue.',
      quickActionTodoTitle: 'Drink 500ml water with lemon'
    },
    {
      id: 'f2',
      category: 'mental-clarity',
      headline: 'Visual & Screen Decompression',
      actionableTip: 'Look at an object 20 feet away through a window for 2 solid minutes.',
      scientificWhy: 'Relaxes the ciliary muscles of the eyes and signals nervous system calm.',
      quickActionTodoTitle: '20-20-20 eye relaxation break'
    },
    {
      id: 'f3',
      category: 'exercise',
      headline: 'Thoracic Spine Mobility',
      actionableTip: 'Stand up and perform 10 chest openers and gentle torso rotations.',
      scientificWhy: 'Releases upper back tension from seated postures and improves oxygen intake.',
      quickActionTodoTitle: '5-minute posture stretches'
    },
    {
      id: 'f4',
      category: 'nutrition',
      headline: 'Balanced Protein-Fiber Snack',
      actionableTip: 'Pair raw almonds or walnuts with an apple or blueberries.',
      scientificWhy: 'Prevents insulin spikes and sustains neurotransmitter focus for the afternoon.',
      quickActionTodoTitle: 'Eat a clean protein & fiber snack'
    }
  ];
}
