import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { TodoList } from './components/TodoList';
import { HealthSuggestions } from './components/HealthSuggestions';
import { WaterAndBreathing } from './components/WaterAndBreathing';
import { AiCoachChat } from './components/AiCoachChat';
import { fetchPersonalizedHealthSuggestions } from './services/geminiService';
import { AiSuggestion, HealthMetricState, TodoItem } from './types';
import { Sparkles, CheckSquare, HeartPulse, MessageSquare } from 'lucide-react';

const STORAGE_KEY_TODOS = 'vitalbloom_todos_v1';
const STORAGE_KEY_METRICS = 'vitalbloom_metrics_v1';

const defaultTodos: TodoItem[] = [
  {
    id: 't1',
    title: 'Morning sunlight & 500ml water',
    category: 'hydration',
    completed: true,
    timeEstimate: '10 min',
    priority: 'high',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't2',
    title: 'Post-lunch 15-minute brisk walk',
    category: 'movement',
    completed: false,
    timeEstimate: '15 min',
    priority: 'high',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't3',
    title: 'Eat leafy greens with lunch & olive oil',
    category: 'nutrition',
    completed: false,
    timeEstimate: '20 min',
    priority: 'medium',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't4',
    title: '4-7-8 Breathing relaxation session',
    category: 'mind',
    completed: false,
    timeEstimate: '5 min',
    priority: 'low',
    createdAt: new Date().toISOString(),
  },
  {
    id: 't5',
    title: 'No screen time 45 min before bed',
    category: 'sleep',
    completed: false,
    timeEstimate: '45 min',
    priority: 'high',
    createdAt: new Date().toISOString(),
  },
];

const defaultMetrics: HealthMetricState = {
  waterGlasses: 4,
  sleepHours: 7.5,
  mood: 'calm',
  dailyScore: 82,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'todos' | 'suggestions' | 'coach'>('overview');

  // Todos state with local storage
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TODOS);
      return saved ? JSON.parse(saved) : defaultTodos;
    } catch {
      return defaultTodos;
    }
  });

  // Health Metrics
  const [metrics, setMetrics] = useState<HealthMetricState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_METRICS);
      return saved ? JSON.parse(saved) : defaultMetrics;
    } catch {
      return defaultMetrics;
    }
  });

  // AI Suggestions state
  const [suggestions, setSuggestions] = useState<AiSuggestion[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TODOS, JSON.stringify(todos));
    } catch (e) {
      console.warn('Failed saving todos to localStorage', e);
    }
  }, [todos]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_METRICS, JSON.stringify(metrics));
    } catch (e) {
      console.warn('Failed saving metrics to localStorage', e);
    }
  }, [metrics]);

  // Load initial suggestions
  const loadSuggestions = async () => {
    setLoadingSuggestions(true);
    try {
      const results = await fetchPersonalizedHealthSuggestions(metrics, todos);
      setSuggestions(results);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSuggestions(false);
    }
  };

  useEffect(() => {
    loadSuggestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleToggleTodo = (id: string) => {
    setTodos((prev) =>
      prev.map((item) => (item.id === id ? { ...item, completed: !item.completed } : item))
    );
  };

  const handleAddTodo = (todoData: Omit<TodoItem, 'id' | 'createdAt'>) => {
    const newTodo: TodoItem = {
      ...todoData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setTodos((prev) => [newTodo, ...prev]);
  };

  const handleDeleteTodo = (id: string) => {
    setTodos((prev) => prev.filter((item) => item.id !== id));
  };

  const handleAddFromSuggestion = (title: string, category: string) => {
    const validCat = ['movement', 'nutrition', 'mind', 'hydration', 'sleep'].includes(category)
      ? (category as any)
      : 'mind';

    handleAddTodo({
      title,
      category: validCat,
      completed: false,
      priority: 'high',
      timeEstimate: '10 min',
    });
    setActiveTab('todos');
  };

  const handleUpdateMetrics = (newValues: Partial<HealthMetricState>) => {
    setMetrics((prev) => ({ ...prev, ...newValues }));
  };

  const completedCount = todos.filter((t) => t.completed).length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar
        completedCount={completedCount}
        totalCount={todos.length}
        streakDays={5}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Tab switcher view */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <Dashboard
              metrics={metrics}
              onUpdateMetrics={handleUpdateMetrics}
              todos={todos}
              onNavigateToTab={setActiveTab}
            />

            <WaterAndBreathing
              waterGlasses={metrics.waterGlasses}
              onUpdateWater={(count) => handleUpdateMetrics({ waterGlasses: count })}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <TodoList
                todos={todos.slice(0, 5)}
                onToggleTodo={handleToggleTodo}
                onAddTodo={handleAddTodo}
                onDeleteTodo={handleDeleteTodo}
              />
              <HealthSuggestions
                suggestions={suggestions}
                loading={loadingSuggestions}
                onRefresh={loadSuggestions}
                onAddTodoFromSuggestion={handleAddFromSuggestion}
              />
            </div>
          </div>
        )}

        {activeTab === 'todos' && (
          <div className="space-y-6">
            <TodoList
              todos={todos}
              onToggleTodo={handleToggleTodo}
              onAddTodo={handleAddTodo}
              onDeleteTodo={handleDeleteTodo}
            />
            <WaterAndBreathing
              waterGlasses={metrics.waterGlasses}
              onUpdateWater={(count) => handleUpdateMetrics({ waterGlasses: count })}
            />
          </div>
        )}

        {activeTab === 'suggestions' && (
          <div className="space-y-6">
            <HealthSuggestions
              suggestions={suggestions}
              loading={loadingSuggestions}
              onRefresh={loadSuggestions}
              onAddTodoFromSuggestion={handleAddFromSuggestion}
            />
          </div>
        )}

        {activeTab === 'coach' && (
          <div className="space-y-6">
            <AiCoachChat metrics={metrics} todos={todos} />
          </div>
        )}
      </main>

      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© {new Date().getFullYear()} VitalBloom. Powered by Gemini 2.5 Flash.</p>
          <p className="text-slate-400">Data persists locally on this device.</p>
        </div>
      </footer>
    </div>
  );
}
