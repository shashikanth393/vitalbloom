export type HabitCategory = 'movement' | 'nutrition' | 'mind' | 'hydration' | 'sleep' | 'personal';

export interface TodoItem {
  id: string;
  title: string;
  category: HabitCategory;
  completed: boolean;
  timeEstimate?: string;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface HealthMetricState {
  waterGlasses: number; // target 8 glasses
  sleepHours: number;
  mood: 'energized' | 'calm' | 'tired' | 'stressed' | 'neutral';
  dailyScore: number;
}

export interface AiSuggestion {
  id: string;
  category: 'nutrition' | 'exercise' | 'recovery' | 'mental-clarity';
  headline: string;
  actionableTip: string;
  scientificWhy: string;
  quickActionTodoTitle?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
