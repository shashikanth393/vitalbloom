import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Trash2, 
  Clock, 
  Filter, 
  Zap, 
  Dumbbell, 
  Apple, 
  Brain, 
  Moon, 
  Droplet,
  Tag
} from 'lucide-react';
import { HabitCategory, TodoItem } from '../types';

interface TodoListProps {
  todos: TodoItem[];
  onToggleTodo: (id: string) => void;
  onAddTodo: (todo: Omit<TodoItem, 'id' | 'createdAt'>) => void;
  onDeleteTodo: (id: string) => void;
}

export const TodoList: React.FC<TodoListProps> = ({
  todos,
  onToggleTodo,
  onAddTodo,
  onDeleteTodo,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<HabitCategory>('movement');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newTimeEstimate, setNewTimeEstimate] = useState('10 min');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddTodo({
      title: newTitle.trim(),
      category: newCategory,
      priority: newPriority,
      timeEstimate: newTimeEstimate,
      completed: false,
    });
    setNewTitle('');
  };

  const filteredTodos = todos.filter((item) => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'pending') return !item.completed;
    if (filterCategory === 'completed') return item.completed;
    return item.category === filterCategory;
  });

  const getCategoryIcon = (category: HabitCategory) => {
    switch (category) {
      case 'movement':
        return <Dumbbell className="w-4 h-4 text-emerald-600" />;
      case 'nutrition':
        return <Apple className="w-4 h-4 text-rose-500" />;
      case 'mind':
        return <Brain className="w-4 h-4 text-indigo-500" />;
      case 'sleep':
        return <Moon className="w-4 h-4 text-purple-500" />;
      case 'hydration':
        return <Droplet className="w-4 h-4 text-sky-500" />;
      default:
        return <Tag className="w-4 h-4 text-slate-500" />;
    }
  };

  const getPriorityBadge = (priority: 'low' | 'medium' | 'high') => {
    switch (priority) {
      case 'high':
        return <span className="text-[11px] px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 font-semibold border border-rose-200">High</span>;
      case 'medium':
        return <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 font-semibold border border-amber-200">Medium</span>;
      case 'low':
        return <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">Low</span>;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-6">
      {/* Header and Add Task Form */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Today's Wellness Tasks</h2>
            <p className="text-xs text-slate-500 mt-0.5">Stay consistent with micro-habits and healthy daily milestones</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-lg">
              {todos.filter(t => t.completed).length} of {todos.length} Complete
            </span>
          </div>
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder="e.g. 15-minute brisk walk after lunch, 500ml water..."
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all shadow-sm shadow-emerald-200"
            >
              <Plus className="w-4 h-4" />
              Add Task
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 text-slate-600">
              <span className="font-medium text-slate-400">Category:</span>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as HabitCategory)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700 font-medium focus:outline-none"
              >
                <option value="movement">Movement</option>
                <option value="nutrition">Nutrition</option>
                <option value="mind">Mindfulness</option>
                <option value="hydration">Hydration</option>
                <option value="sleep">Sleep Prep</option>
                <option value="personal">Personal</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-slate-600">
              <span className="font-medium text-slate-400">Priority:</span>
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as 'low' | 'medium' | 'high')}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700 font-medium focus:outline-none"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-slate-600">
              <span className="font-medium text-slate-400">Duration:</span>
              <input
                type="text"
                value={newTimeEstimate}
                onChange={(e) => setNewTimeEstimate(e.target.value)}
                className="w-20 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700 font-medium focus:outline-none"
                placeholder="10 min"
              />
            </div>
          </div>
        </form>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        {['all', 'pending', 'completed', 'movement', 'nutrition', 'mind', 'hydration'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 rounded-lg capitalize font-medium transition-all whitespace-nowrap ${
              filterCategory === cat
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Todo items */}
      <div className="space-y-2.5">
        {filteredTodos.length === 0 ? (
          <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-xl">
            <Zap className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">No tasks in this category</p>
            <p className="text-xs text-slate-400 mt-1">Add a quick wellness goal or tap recommendations below!</p>
          </div>
        ) : (
          filteredTodos.map((todo) => (
            <div
              key={todo.id}
              className={`group flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                todo.completed
                  ? 'bg-slate-50/70 border-slate-200/60 opacity-75'
                  : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-sm'
              }`}
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <button
                  type="button"
                  onClick={() => onToggleTodo(todo.id)}
                  className="text-slate-400 hover:text-emerald-600 transition-colors focus:outline-none"
                >
                  {todo.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                  ) : (
                    <Circle className="w-5 h-5 hover:stroke-emerald-600" />
                  )}
                </button>

                <div className="min-w-0">
                  <p
                    className={`text-sm font-semibold truncate ${
                      todo.completed ? 'line-through text-slate-400' : 'text-slate-800'
                    }`}
                  >
                    {todo.title}
                  </p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                    <span className="flex items-center gap-1 capitalize">
                      {getCategoryIcon(todo.category)}
                      {todo.category}
                    </span>
                    {todo.timeEstimate && (
                      <span className="flex items-center gap-1 text-slate-400">
                        <Clock className="w-3 h-3" />
                        {todo.timeEstimate}
                      </span>
                    )}
                    <div>{getPriorityBadge(todo.priority)}</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pl-2">
                <button
                  type="button"
                  onClick={() => onDeleteTodo(todo.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors opacity-80 group-hover:opacity-100"
                  title="Delete habit"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
