import React, { useState, useEffect } from 'react';
import { Droplet, Plus, Minus, Wind, Play, Pause, RotateCcw } from 'lucide-react';

interface WaterAndBreathingProps {
  waterGlasses: number;
  onUpdateWater: (count: number) => void;
}

export const WaterAndBreathing: React.FC<WaterAndBreathingProps> = ({
  waterGlasses,
  onUpdateWater,
}) => {
  // Breathing state
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);

  useEffect(() => {
    if (!breathingActive) return;

    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev > 1) return prev - 1;

        // Transition cycle: Inhale (4s) -> Hold (7s) -> Exhale (8s)
        if (breathPhase === 'Inhale') {
          setBreathPhase('Hold');
          return 7;
        } else if (breathPhase === 'Hold') {
          setBreathPhase('Exhale');
          return 8;
        } else {
          setBreathPhase('Inhale');
          return 4;
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [breathingActive, breathPhase]);

  const targetWater = 8;
  const percentage = Math.min(100, Math.round((waterGlasses / targetWater) * 100));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Hydration Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-600 flex items-center justify-center">
                <Droplet className="w-4 h-4 fill-sky-500" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Hydration Tracker</h3>
                <p className="text-xs text-slate-500">Goal: 8 glasses (2.0 Liters)</p>
              </div>
            </div>
            <span className="text-sm font-bold text-sky-600">{percentage}%</span>
          </div>

          {/* Glasses visual */}
          <div className="mt-5 space-y-4">
            <div className="grid grid-cols-8 gap-1.5 sm:gap-2">
              {Array.from({ length: 8 }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => onUpdateWater(idx + 1 === waterGlasses ? idx : idx + 1)}
                  className={`h-12 rounded-lg flex flex-col items-center justify-center transition-all ${
                    idx < waterGlasses
                      ? 'bg-sky-500 text-white shadow-sm shadow-sky-200'
                      : 'bg-slate-100 hover:bg-sky-100 text-slate-400'
                  }`}
                  title={`Glass ${idx + 1}`}
                >
                  <Droplet className="w-4 h-4" />
                  <span className="text-[10px] font-bold mt-0.5">{idx + 1}</span>
                </button>
              ))}
            </div>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-sky-500 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${percentage}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            {waterGlasses >= 8 ? '🎉 Hydration target reached!' : `${8 - waterGlasses} glasses remaining`}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onUpdateWater(Math.max(0, waterGlasses - 1))}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
            >
              <Minus className="w-4 h-4" />
            </button>
            <button
              onClick={() => onUpdateWater(Math.min(12, waterGlasses + 1))}
              className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm shadow-sky-200"
            >
              <Plus className="w-4 h-4" />
              Add Glass
            </button>
          </div>
        </div>
      </div>

      {/* Guided 4-7-8 Breathing */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-600 flex items-center justify-center">
                <Wind className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">4-7-8 Calming Breath</h3>
                <p className="text-xs text-slate-500">Instant vagus nerve reset</p>
              </div>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
              Vagus Reset
            </span>
          </div>

          <div className="mt-4 flex flex-col items-center justify-center py-2">
            <div
              className={`w-28 h-28 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-700 ${
                breathingActive
                  ? breathPhase === 'Inhale'
                    ? 'border-emerald-500 bg-emerald-50 scale-110 shadow-lg shadow-emerald-100'
                    : breathPhase === 'Hold'
                    ? 'border-amber-400 bg-amber-50 scale-105'
                    : 'border-sky-400 bg-sky-50 scale-95'
                  : 'border-slate-200 bg-slate-50'
              }`}
            >
              <span className="text-xs uppercase tracking-wider font-bold text-slate-500">
                {breathingActive ? breathPhase : 'Ready'}
              </span>
              <span className="text-2xl font-black text-slate-800">
                {breathingActive ? `${secondsLeft}s` : 'Start'}
              </span>
            </div>

            <p className="text-xs text-slate-500 text-center mt-3 max-w-xs">
              {breathPhase === 'Inhale'
                ? 'Deep breath through your nose'
                : breathPhase === 'Hold'
                ? 'Gently retain air with relaxed shoulders'
                : 'Whoosh exhale completely through mouth'}
            </p>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-400">Takes only 1 minute</span>
          <div className="flex items-center gap-2">
            {breathingActive && (
              <button
                onClick={() => {
                  setBreathingActive(false);
                  setBreathPhase('Inhale');
                  setSecondsLeft(4);
                }}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                title="Reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => setBreathingActive(!breathingActive)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                breathingActive
                  ? 'bg-amber-500 hover:bg-amber-600 text-white'
                  : 'bg-teal-600 hover:bg-teal-700 text-white shadow-sm shadow-teal-200'
              }`}
            >
              {breathingActive ? (
                <>
                  <Pause className="w-3.5 h-3.5" /> Pause
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" /> Start Exercise
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
