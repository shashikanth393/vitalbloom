import React from 'react';
import { Sparkles, PlusCircle, Lightbulb, Activity, Flame, ShieldCheck } from 'lucide-react';
import { AiSuggestion } from '../types';

interface HealthSuggestionsProps {
  suggestions: AiSuggestion[];
  loading: boolean;
  onRefresh: () => void;
  onAddTodoFromSuggestion: (title: string, category: string) => void;
}

export const HealthSuggestions: React.FC<HealthSuggestionsProps> = ({
  suggestions,
  loading,
  onRefresh,
  onAddTodoFromSuggestion,
}) => {
  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'nutrition':
        return 'bg-rose-50 border-rose-200 text-rose-700';
      case 'exercise':
        return 'bg-emerald-50 border-emerald-200 text-emerald-700';
      case 'recovery':
        return 'bg-purple-50 border-purple-200 text-purple-700';
      case 'mental-clarity':
        return 'bg-sky-50 border-sky-200 text-sky-700';
      default:
        return 'bg-amber-50 border-amber-200 text-amber-700';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">AI Health Suggestions</h2>
            <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 bg-gradient-to-r from-amber-500 to-orange-400 text-white rounded-full">
              <Sparkles className="w-3 h-3" />
              Gemini 2.5
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time personalized micro-interventions tuned to your energy, sleep & habits
          </p>
        </div>

        <button
          onClick={onRefresh}
          disabled={loading}
          className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex items-center justify-center gap-2 self-start sm:self-auto disabled:opacity-50"
        >
          <Sparkles className={`w-3.5 h-3.5 text-amber-500 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Analyzing Vitals...' : 'Refresh Insights'}
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-pulse">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-44 bg-slate-100 rounded-xl p-4 space-y-3">
              <div className="w-24 h-5 bg-slate-200 rounded"></div>
              <div className="w-3/4 h-6 bg-slate-200 rounded"></div>
              <div className="w-full h-12 bg-slate-200 rounded"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {suggestions.map((item) => (
            <div
              key={item.id}
              className="flex flex-col justify-between p-5 rounded-xl border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all bg-gradient-to-br from-white to-slate-50/50"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span
                    className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md border ${getCategoryColor(
                      item.category
                    )}`}
                  >
                    {item.category.replace('-', ' ')}
                  </span>
                  <Lightbulb className="w-4 h-4 text-amber-400" />
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 leading-snug">{item.headline}</h3>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{item.actionableTip}</p>
                </div>

                <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-[11px] text-emerald-800 flex items-start gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong className="font-semibold">Why this works:</strong> {item.scientificWhy}
                  </span>
                </div>
              </div>

              {item.quickActionTodoTitle && (
                <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] font-medium text-slate-400 truncate max-w-[200px]">
                    Action: {item.quickActionTodoTitle}
                  </span>
                  <button
                    onClick={() =>
                      onAddTodoFromSuggestion(item.quickActionTodoTitle || item.headline, item.category)
                    }
                    className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    Add to Todo
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
