import React from 'react';
import { HeartPulse, Sparkles, CheckCircle2, Droplets, Calendar } from 'lucide-react';

interface NavbarProps {
  completedCount: number;
  totalCount: number;
  streakDays: number;
  activeTab: 'overview' | 'todos' | 'suggestions' | 'coach';
  setActiveTab: (tab: 'overview' | 'todos' | 'suggestions' | 'coach') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  completedCount,
  totalCount,
  streakDays,
  activeTab,
  setActiveTab,
}) => {
  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('overview')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-200">
              <HeartPulse className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg text-slate-900 tracking-tight">VitalBloom</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded">AI</span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">Holistic Health & Routine</p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center space-x-1 sm:space-x-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'overview'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('todos')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'todos'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daily Todos
              {totalCount > 0 && (
                <span className="bg-emerald-100 text-emerald-700 text-xs px-1.5 py-0.2 rounded-full font-bold">
                  {completedCount}/{totalCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('suggestions')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'suggestions'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              AI Suggestions
            </button>
            <button
              onClick={() => setActiveTab('coach')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'coach'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Wellness Coach
            </button>
          </nav>

          {/* Quick Metrics */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-1.5 text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-700 rounded-lg border border-amber-200">
              <span>🔥</span>
              <span>{streakDays} Day Streak</span>
            </div>
            <div className="flex items-center space-x-1 text-xs text-slate-500">
              <Calendar className="w-3.5 h-3.5" />
              <span>{today}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
