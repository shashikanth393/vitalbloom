import React from 'react';
import { 
  Heart, 
  Moon, 
  Droplet, 
  CheckCircle, 
  TrendingUp, 
  Sparkles, 
  Smile, 
  Activity 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';
import { HealthMetricState, TodoItem } from '../types';

interface DashboardProps {
  metrics: HealthMetricState;
  onUpdateMetrics: (newMetrics: Partial<HealthMetricState>) => void;
  todos: TodoItem[];
  onNavigateToTab: (tab: 'overview' | 'todos' | 'suggestions' | 'coach') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  metrics,
  onUpdateMetrics,
  todos,
  onNavigateToTab,
}) => {
  const completedCount = todos.filter((t) => t.completed).length;
  const totalCount = todos.length;
  const completionRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Mock weekly wellness history
  const weeklyTrendData = [
    { day: 'Mon', completion: 70, water: 7, sleep: 7.2 },
    { day: 'Tue', completion: 85, water: 8, sleep: 6.8 },
    { day: 'Wed', completion: 60, water: 6, sleep: 7.5 },
    { day: 'Thu', completion: 90, water: 8, sleep: 8.0 },
    { day: 'Fri', completion: 80, water: 7, sleep: 7.0 },
    { day: 'Sat', completion: 95, water: 9, sleep: 8.5 },
    { day: 'Today', completion: completionRate, water: metrics.waterGlasses, sleep: metrics.sleepHours },
  ];

  const moodList: Array<{ value: HealthMetricState['mood']; label: string; icon: string }> = [
    { value: 'energized', label: 'Energized', icon: '⚡' },
    { value: 'calm', label: 'Calm', icon: '🌿' },
    { value: 'neutral', label: 'Neutral', icon: '☁️' },
    { value: 'tired', label: 'Tired', icon: '🥱' },
    { value: 'stressed', label: 'Stressed', icon: '🔥' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner / Mood Check-in */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold tracking-widest text-emerald-200">
              Personalized Wellness Center
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Good day! How are you feeling right now?
            </h1>
            <p className="text-emerald-100 text-sm max-w-xl">
              Log your mood & sleep to let our Gemini health intelligence adapt your daily todo recommendations.
            </p>
          </div>

          {/* Mood Selectors */}
          <div className="flex flex-wrap gap-2">
            {moodList.map((m) => (
              <button
                key={m.value}
                onClick={() => onUpdateMetrics({ mood: m.value })}
                className={`px-3.5 py-2 rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  metrics.mood === m.value
                    ? 'bg-white text-slate-900 shadow-md scale-105'
                    : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
              >
                <span>{m.icon}</span>
                <span>{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Quick stat row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-white/20">
          <div>
            <p className="text-xs text-emerald-200 font-medium">Daily Task Rate</p>
            <p className="text-2xl font-bold mt-0.5">{completionRate}%</p>
          </div>
          <div>
            <p className="text-xs text-emerald-200 font-medium">Water Target</p>
            <p className="text-2xl font-bold mt-0.5">{metrics.waterGlasses} / 8 glasses</p>
          </div>
          <div>
            <p className="text-xs text-emerald-200 font-medium">Sleep Last Night</p>
            <p className="text-2xl font-bold mt-0.5">{metrics.sleepHours} hrs</p>
          </div>
          <div>
            <p className="text-xs text-emerald-200 font-medium">Current State</p>
            <p className="text-2xl font-bold mt-0.5 capitalize">{metrics.mood}</p>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Metric 1: Sleep */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Sleep Quality</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <Moon className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-extrabold text-slate-900">{metrics.sleepHours}</span>
              <span className="text-sm font-semibold text-slate-400">hrs</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">Target: 7.5 - 8.5 hours</p>
          </div>
          <div className="flex items-center gap-2 pt-2">
            {[6, 7, 7.5, 8, 9].map((hrs) => (
              <button
                key={hrs}
                onClick={() => onUpdateMetrics({ sleepHours: hrs })}
                className={`px-2 py-1 text-xs rounded-lg font-medium transition-colors ${
                  metrics.sleepHours === hrs
                    ? 'bg-purple-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {hrs}h
              </button>
            ))}
          </div>
        </div>

        {/* Metric 2: Todo Progress */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Habit Completion</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-extrabold text-slate-900">{completedCount}</span>
              <span className="text-sm font-semibold text-slate-400">/ {totalCount} habits</span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-500 h-2 rounded-full transition-all"
                style={{ width: `${completionRate}%` }}
              ></div>
            </div>
          </div>
          <button
            onClick={() => onNavigateToTab('todos')}
            className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 pt-1"
          >
            Manage Daily Todos &rarr;
          </button>
        </div>

        {/* Metric 3: AI Wellness Score */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Vital Score</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-extrabold text-slate-900">
                {Math.min(98, Math.round(completionRate * 0.4 + (metrics.waterGlasses / 8) * 30 + (metrics.sleepHours / 8) * 30))}
              </span>
              <span className="text-sm font-semibold text-slate-400">/ 100</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">Based on sleep, hydration & habit consistency</p>
          </div>
          <button
            onClick={() => onNavigateToTab('suggestions')}
            className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 pt-1"
          >
            View AI Suggestions &rarr;
          </button>
        </div>
      </div>

      {/* Weekly Trend Chart */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">Weekly Habit Consistency</h3>
            <p className="text-xs text-slate-500">Track your daily wellness compliance rate (%)</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-lg">
            Consistent Streak
          </span>
        </div>

        <div className="h-64 mt-4 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                cursor={{ fill: '#f8fafc' }}
              />
              <Bar dataKey="completion" fill="#10b981" radius={[6, 6, 0, 0]} name="Completion %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
